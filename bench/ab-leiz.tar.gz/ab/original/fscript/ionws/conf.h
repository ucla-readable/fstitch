/*
 * ion/ionws/conf.h
 *
 * Copyright (c) Tuomo Valkonen 1999-2004. 
 *
 * Ion is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 */

#ifndef ION_IONWS_CONF_H
#define ION_IONWS_CONF_H

extern bool ionws_module_read_config();

#endif /* ION_IONWS_CONF_H */
